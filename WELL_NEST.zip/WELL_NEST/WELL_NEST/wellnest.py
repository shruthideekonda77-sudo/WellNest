import tkinter as tk
from tkinter import ttk, messagebox
import json, os, hashlib, secrets
from datetime import datetime

APP_NAME = "WellNest"
DATA_FILE = "wellnest_data.json"

# Pastel palette
BG = "#F8F3FB"
PANEL = "#FFFCFF"
LAVENDER = "#E9DDF7"
PURPLE = "#9270C5"
DEEP = "#50396F"
PINK = "#F6DCEB"
ROSE = "#D979A9"
CREAM = "#FFF4E4"
MINT = "#DDF1E6"
TEXT = "#493B57"
MUTED = "#8D8098"
GOLD = "#F2C76B"
LINE = "#E9DDF0"


def load_database():
    if not os.path.exists(DATA_FILE):
        return {"users": {}}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict) or not isinstance(data.get("users"), dict):
            raise ValueError("Invalid database structure")
        return data
    except (OSError, json.JSONDecodeError, ValueError):
        messagebox.showerror(
            "WellNest data issue",
            f"Could not read {DATA_FILE}. The file may be damaged.\n"
            "Your existing file has not been overwritten. Restore a backup to continue."
        )
        return {"users": {}}


def save_database(data):
    temp = DATA_FILE + ".tmp"
    with open(temp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    os.replace(temp, DATA_FILE)


def password_hash(password, salt=None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), bytes.fromhex(salt), 240000
    ).hex()
    return salt, digest


def new_user(name, email, password):
    salt, digest = password_hash(password)
    return {
        "name": name,
        "email": email,
        "salt": salt,
        "password_hash": digest,
        "journal": [],
        "moods": [],
        "goals": [],
        "points": 0,
        "created": datetime.now().isoformat(timespec="seconds")
    }


class Mascot(tk.Canvas):
    """Small original vector mascots drawn with Tkinter Canvas (no image files needed)."""
    def __init__(self, parent, kind="cloud", size=150, bg=PANEL):
        super().__init__(parent, width=size, height=size, bg=bg,
                         highlightthickness=0)
        self.size = size
        self.kind = kind
        self.draw()

    def draw(self):
        s = self.size
        c = self
        if self.kind == "cloud":
            # cloud body
            c.create_oval(s*.15, s*.39, s*.52, s*.78, fill="#FFFFFF", outline="#D8C7F0", width=2)
            c.create_oval(s*.34, s*.22, s*.72, s*.76, fill="#FFFFFF", outline="#D8C7F0", width=2)
            c.create_oval(s*.55, s*.39, s*.89, s*.77, fill="#FFFFFF", outline="#D8C7F0", width=2)
            c.create_rectangle(s*.29, s*.54, s*.75, s*.75, fill="#FFFFFF", outline="")
            c.create_oval(s*.29, s*.67, s*.75, s*.82, fill="#FFFFFF", outline="#D8C7F0", width=1)
            # crown
            c.create_polygon(s*.38,s*.28,s*.43,s*.13,s*.52,s*.25,s*.61,s*.11,s*.68,s*.29,
                             fill=GOLD, outline="#D9A94B", width=1)
            c.create_oval(s*.49,s*.18,s*.54,s*.23, fill="#FFF8D9", outline="")
            eye_y = s*.54
            c.create_oval(s*.40,eye_y,s*.44,eye_y+s*.055,fill=DEEP,outline="")
            c.create_oval(s*.59,eye_y,s*.63,eye_y+s*.055,fill=DEEP,outline="")
            c.create_arc(s*.47,s*.55,s*.57,s*.64,start=200,extent=140,style="arc",outline=ROSE,width=2)
            c.create_oval(s*.31,s*.57,s*.38,s*.62,fill="#F8C6D8",outline="")
            c.create_oval(s*.66,s*.57,s*.73,s*.62,fill="#F8C6D8",outline="")
            for x,y in [(s*.18,s*.28),(s*.82,s*.2),(s*.83,s*.78)]:
                c.create_text(x,y,text="✦",fill=GOLD,font=("Arial", max(9,int(s*.12)),"bold"))
        elif self.kind == "bunny":
            c.create_oval(s*.28,s*.05,s*.47,s*.48,fill="#FFF9FC",outline="#D8B7D5",width=2)
            c.create_oval(s*.53,s*.05,s*.72,s*.48,fill="#FFF9FC",outline="#D8B7D5",width=2)
            c.create_oval(s*.31,s*.10,s*.43,s*.42,fill="#F6D7E8",outline="")
            c.create_oval(s*.57,s*.10,s*.69,s*.42,fill="#F6D7E8",outline="")
            c.create_oval(s*.18,s*.30,s*.82,s*.91,fill="#FFF9FC",outline="#D8B7D5",width=2)
            c.create_oval(s*.36,s*.57,s*.40,s*.63,fill=DEEP,outline="")
            c.create_oval(s*.60,s*.57,s*.64,s*.63,fill=DEEP,outline="")
            c.create_oval(s*.47,s*.65,s*.53,s*.70,fill=ROSE,outline="")
            c.create_arc(s*.43,s*.66,s*.57,s*.77,start=200,extent=140,style="arc",outline=ROSE,width=2)
            c.create_oval(s*.26,s*.65,s*.36,s*.72,fill="#F8C6D8",outline="")
            c.create_oval(s*.64,s*.65,s*.74,s*.72,fill="#F8C6D8",outline="")
            c.create_text(s*.75,s*.24,text="✿",fill=ROSE,font=("Arial",int(s*.18),"bold"))
        elif self.kind == "bear":
            c.create_oval(s*.19,s*.25,s*.43,s*.49,fill="#C99478",outline="#A76D58",width=2)
            c.create_oval(s*.57,s*.25,s*.81,s*.49,fill="#C99478",outline="#A76D58",width=2)
            c.create_oval(s*.18,s*.34,s*.82,s*.91,fill="#D9A88D",outline="#A76D58",width=2)
            c.create_oval(s*.35,s*.57,s*.41,s*.64,fill=DEEP,outline="")
            c.create_oval(s*.59,s*.57,s*.65,s*.64,fill=DEEP,outline="")
            c.create_oval(s*.43,s*.65,s*.57,s*.76,fill="#F6E2D5",outline="#C18C75")
            c.create_oval(s*.475,s*.66,s*.525,s*.70,fill=DEEP,outline="")
            c.create_arc(s*.45,s*.68,s*.55,s*.76,start=200,extent=140,style="arc",outline=DEEP,width=2)
            c.create_oval(s*.26,s*.66,s*.35,s*.72,fill="#EFAFC5",outline="")
            c.create_oval(s*.65,s*.66,s*.74,s*.72,fill="#EFAFC5",outline="")
            c.create_text(s*.5,s*.20,text="♥",fill=ROSE,font=("Arial",int(s*.18),"bold"))
        else:  # star fairy
            c.create_polygon(s*.5,s*.08,s*.62,s*.39,s*.94,s*.4,s*.69,s*.6,
                             s*.78,s*.93,s*.5,s*.73,s*.22,s*.93,s*.31,s*.6,
                             s*.06,s*.4,s*.38,s*.39,fill="#F8D77C",outline="#D8A94D",width=2)
            c.create_oval(s*.40,s*.47,s*.44,s*.53,fill=DEEP,outline="")
            c.create_oval(s*.56,s*.47,s*.60,s*.53,fill=DEEP,outline="")
            c.create_arc(s*.44,s*.51,s*.56,s*.62,start=200,extent=140,style="arc",outline=ROSE,width=2)


class WellNestApp:
    def __init__(self, root):
        self.root = root
        self.root.title("WellNest ♡ Your Happy Place")
        self.root.geometry("1180x760")
        self.root.minsize(980, 650)
        self.root.configure(bg=BG)
        self.db = load_database()
        self.email = None
        self.user = None
        self.selected_journal = None
        self.page = None
        self.style = ttk.Style()
        self.style.theme_use("clam")
        self.style.configure("TNotebook", background=BG, borderwidth=0)
        self.show_auth("signin")

    def clear(self):
        for w in self.root.winfo_children():
            w.destroy()

    def label(self, parent, text, size=11, color=TEXT, bold=False, bg=None, **kwargs):
        return tk.Label(parent, text=text, font=("Segoe UI", size, "bold" if bold else "normal"),
                        fg=color, bg=bg or parent.cget("bg"), **kwargs)

    def button(self, parent, text, command, color=PURPLE, fg="white", **kwargs):
        return tk.Button(parent, text=text, command=command, bg=color, fg=fg,
                         activebackground=DEEP, activeforeground="white",
                         relief="flat", bd=0, cursor="hand2",
                         font=("Segoe UI", 10, "bold"), padx=15, pady=10, **kwargs)

    def card(self, parent, padx=18, pady=16):
        return tk.Frame(parent, bg=PANEL, highlightbackground=LINE, highlightthickness=1,
                        padx=padx, pady=pady)

    def save(self):
        try:
            save_database(self.db)
            return True
        except OSError as exc:
            messagebox.showerror("Couldn't save", f"Your changes could not be saved.\n{exc}")
            return False

    # ---------- AUTH ----------
    def show_auth(self, mode):
        self.clear()
        self.page = mode
        outer = tk.Frame(self.root, bg=BG)
        outer.pack(fill="both", expand=True, padx=35, pady=30)
        left = tk.Frame(outer, bg=LAVENDER, width=430)
        left.pack(side="left", fill="both", expand=True)
        left.pack_propagate(False)
        right = tk.Frame(outer, bg=PANEL, padx=48, pady=35)
        right.pack(side="right", fill="both", expand=True)

        self.label(left, "☁  WellNest", 25, DEEP, True, LAVENDER).pack(pady=(35, 4))
        self.label(left, "YOUR LITTLE HAPPY PLACE", 9, ROSE, True, LAVENDER).pack()
        Mascot(left, "bunny", 205, LAVENDER).pack(pady=(30, 8))
        self.label(left, "Dream  •  Journal  •  Grow  •  Thrive", 12, DEEP, True, LAVENDER).pack()
        self.label(left, "Small steps make lovely changes.", 11, MUTED, False, LAVENDER).pack(pady=8)
        mascots = tk.Frame(left, bg=LAVENDER)
        mascots.pack(pady=20)
        for kind in ("bunny", "bear", "star"):
            Mascot(mascots, kind, 78, LAVENDER).pack(side="left", padx=5)

        if mode == "signin":
            self.label(right, "Welcome back! ♡", 25, DEEP, True, PANEL).pack(anchor="w", pady=(30, 5))
            self.label(right, "Your cozy corner is waiting for you.", 11, MUTED, bg=PANEL).pack(anchor="w", pady=(0, 28))
            self.label(right, "Email address", 10, TEXT, True, PANEL).pack(anchor="w")
            self.email_entry = self.entry(right, "you@example.com")
            self.label(right, "Password", 10, TEXT, True, PANEL).pack(anchor="w", pady=(14, 0))
            self.pass_entry = self.entry(right, "At least 8 characters", show="•")
            self.button(right, "Sign in  ✦", self.login).pack(fill="x", pady=25)
            row = tk.Frame(right, bg=PANEL)
            row.pack()
            self.label(row, "New to WellNest? ", 10, MUTED, bg=PANEL).pack(side="left")
            tk.Button(row, text="Create account", command=lambda: self.show_auth("signup"),
                      bg=PANEL, fg=ROSE, relief="flat", cursor="hand2",
                      font=("Segoe UI", 10, "bold")).pack(side="left")
        else:
            self.label(right, "Create your account ♡", 23, DEEP, True, PANEL).pack(anchor="w", pady=(5, 5))
            self.label(right, "Let's make this a kinder space for you.", 11, MUTED, bg=PANEL).pack(anchor="w", pady=(0, 20))
            self.label(right, "Your name", 10, TEXT, True, PANEL).pack(anchor="w")
            self.name_entry = self.entry(right, "What should we call you?")
            self.label(right, "Email address", 10, TEXT, True, PANEL).pack(anchor="w", pady=(10, 0))
            self.email_entry = self.entry(right, "you@example.com")
            self.label(right, "Password", 10, TEXT, True, PANEL).pack(anchor="w", pady=(10, 0))
            self.pass_entry = self.entry(right, "At least 8 characters", show="•")
            self.label(right, "Confirm password", 10, TEXT, True, PANEL).pack(anchor="w", pady=(10, 0))
            self.confirm_entry = self.entry(right, "Type password again", show="•")
            self.button(right, "Create my happy place  ✦", self.signup).pack(fill="x", pady=20)
            row = tk.Frame(right, bg=PANEL)
            row.pack()
            self.label(row, "Already have an account? ", 10, MUTED, bg=PANEL).pack(side="left")
            tk.Button(row, text="Sign in", command=lambda: self.show_auth("signin"),
                      bg=PANEL, fg=ROSE, relief="flat", cursor="hand2",
                      font=("Segoe UI", 10, "bold")).pack(side="left")

    def entry(self, parent, placeholder, show=None):
        e = tk.Entry(parent, font=("Segoe UI", 11), bg="#FBF7FD", fg=TEXT,
                     insertbackground=TEXT, relief="flat", highlightthickness=1,
                     highlightbackground=LINE, highlightcolor=PURPLE, show=show)
        e.pack(fill="x", ipady=11, pady=7)
        e.insert(0, placeholder)
        e.bind("<FocusIn>", lambda ev: e.delete(0, "end") if e.get() == placeholder else None)
        return e

    def signup(self):
        name = self.name_entry.get().strip()
        email = self.email_entry.get().strip().lower()
        pw = self.pass_entry.get()
        confirm = self.confirm_entry.get()
        if not name or name == "What should we call you?":
            messagebox.showwarning("A little detail", "Please enter your name.")
            return
        if "@" not in email or "." not in email.split("@")[-1]:
            messagebox.showwarning("Check your email", "Please enter a valid email address.")
            return
        if email in self.db["users"]:
            messagebox.showwarning("Account exists", "This email is already registered. Please sign in.")
            return
        if len(pw) < 8:
            messagebox.showwarning("Password too short", "Use at least 8 characters.")
            return
        if pw != confirm:
            messagebox.showwarning("Passwords don't match", "Please check both password fields.")
            return
        self.db["users"][email] = new_user(name, email, pw)
        if self.save():
            messagebox.showinfo("Welcome to WellNest!", "Your account is ready. Let's grow gently together! ♡")
            self.show_auth("signin")

    def login(self):
        email = self.email_entry.get().strip().lower()
        pw = self.pass_entry.get()
        user = self.db["users"].get(email)
        if not user:
            messagebox.showerror("Couldn't sign in", "No account found for this email.")
            return
        _, digest = password_hash(pw, user["salt"])
        if not secrets.compare_digest(digest, user["password_hash"]):
            messagebox.showerror("Couldn't sign in", "That password doesn't match. Try again.")
            return
        self.email, self.user = email, user
        self.show_app()

    # ---------- MAIN APP ----------
    def show_app(self):
        self.clear()
        shell = tk.Frame(self.root, bg=BG)
        shell.pack(fill="both", expand=True)
        self.sidebar = tk.Frame(shell, bg=LAVENDER, width=220)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)
        self.content = tk.Frame(shell, bg=BG)
        self.content.pack(side="right", fill="both", expand=True)

        self.label(self.sidebar, "♡ WellNest", 21, DEEP, True, LAVENDER).pack(pady=(25, 2))
        self.label(self.sidebar, "YOUR HAPPY PLACE", 8, ROSE, True, LAVENDER).pack(pady=(0, 15))
        Mascot(self.sidebar, "bunny", 105, LAVENDER).pack(pady=5)
        self.label(self.sidebar, f"Hi, {self.user['name'].split()[0]} ♡", 12, DEEP, True, LAVENDER).pack(pady=(3, 18))
        navs = [
            ("⌂  Dashboard", "dashboard"), ("✎  Journal", "journal"),
            ("♡  Mood check-in", "mood"), ("☆  My goals", "goals"),
            ("♙  Profile", "profile")
        ]
        for text, key in navs:
            tk.Button(self.sidebar, text=text, command=lambda k=key: self.navigate(k),
                      anchor="w", bg=LAVENDER, fg=DEEP, activebackground=PINK,
                      activeforeground=DEEP, relief="flat", bd=0, cursor="hand2",
                      font=("Segoe UI", 11, "bold"), padx=20, pady=11).pack(fill="x", padx=10, pady=2)
        self.button(self.sidebar, "Log out", self.logout, color=ROSE).pack(side="bottom", fill="x", padx=18, pady=20)
        self.navigate("dashboard")

    def navigate(self, page):
        self.current_page = page
        for w in self.content.winfo_children():
            w.destroy()
        pages = {
            "dashboard": self.page_dashboard, "journal": self.page_journal,
            "mood": self.page_mood, "goals": self.page_goals,
            "profile": self.page_profile
        }
        pages[page]()

    def page_header(self, title, subtitle):
        top = tk.Frame(self.content, bg=BG)
        top.pack(fill="x", padx=30, pady=(25, 18))
        self.label(top, title, 23, DEEP, True, BG).pack(anchor="w")
        self.label(top, subtitle, 10, MUTED, bg=BG).pack(anchor="w", pady=(4, 0))

    def stat_card(self, parent, title, value, emoji, color):
        f = tk.Frame(parent, bg=color, padx=18, pady=17, highlightthickness=1, highlightbackground=LINE)
        self.label(f, emoji, 22, DEEP, bg=color).pack(anchor="w")
        self.label(f, str(value), 22, DEEP, True, color).pack(anchor="w", pady=(6, 0))
        self.label(f, title, 10, MUTED, True, color).pack(anchor="w")
        return f

    def page_dashboard(self):
        self.page_header(f"Hello, {self.user['name'].split()[0]}! ♡", "You don't have to do everything today. Just one kind thing for yourself.")
        row = tk.Frame(self.content, bg=BG)
        row.pack(fill="x", padx=25)
        stats = [
            ("Journal entries", len(self.user["journal"]), "📖", CREAM),
            ("Mood check-ins", len(self.user["moods"]), "🌷", PINK),
            ("Wellness points", self.user.get("points", 0), "⭐", LAVENDER),
            ("Active goals", sum(not g.get("done", False) for g in self.user["goals"]), "🎯", MINT)
        ]
        for title, value, emoji, color in stats:
            self.stat_card(row, title, value, emoji, color).pack(side="left", fill="both", expand=True, padx=6)

        mid = tk.Frame(self.content, bg=BG)
        mid.pack(fill="both", expand=True, padx=30, pady=20)
        welcome = self.card(mid, 20, 18)
        welcome.pack(side="left", fill="both", expand=True, padx=(0, 10))
        self.label(welcome, "A little reminder for you", 15, DEEP, True, PANEL).pack(anchor="w")
        self.label(welcome, "You are allowed to grow at your own pace.", 12, TEXT, bg=PANEL, wraplength=390).pack(anchor="w", pady=10)
        Mascot(welcome, "bunny", 145, PANEL).pack(pady=5)
        self.label(welcome, "Luna says: You're doing better than you think! ♡", 10, ROSE, True, PANEL).pack()

        quick = self.card(mid, 20, 18)
        quick.pack(side="right", fill="both", expand=True, padx=(10, 0))
        self.label(quick, "Quick actions ✨", 15, DEEP, True, PANEL).pack(anchor="w", pady=(0, 12))
        for title, page, color in [
            ("Write in my journal  ✎", "journal", PURPLE),
            ("Check in with my mood  ♡", "mood", ROSE),
            ("Set a tiny goal  ☆", "goals", "#79A88D")
        ]:
            self.button(quick, title, lambda p=page: self.navigate(p), color=color).pack(fill="x", pady=6)
        recent = self.card(self.content)
        recent.pack(fill="x", padx=30, pady=(0, 25))
        self.label(recent, "Your latest journal thought", 13, DEEP, True, PANEL).pack(anchor="w")
        if self.user["journal"]:
            item = self.user["journal"][-1]
            self.label(recent, f"{item['title']}  ·  {item['date']}", 10, MUTED, bg=PANEL).pack(anchor="w", pady=5)
            self.label(recent, item["content"][:180], 11, TEXT, bg=PANEL, wraplength=800, justify="left").pack(anchor="w")
        else:
            self.label(recent, "Your page is waiting for your first little story. ♡", 11, MUTED, bg=PANEL).pack(anchor="w", pady=5)

    # ---------- JOURNAL ----------
    def page_journal(self):
        self.page_header("My little journal  ✎", "A safe page for all the thoughts you want to let out.")
        body = tk.Frame(self.content, bg=BG)
        body.pack(fill="both", expand=True, padx=28, pady=(0, 25))
        editor = self.card(body)
        editor.pack(side="left", fill="both", expand=True, padx=(0, 10))
        self.label(editor, "Create a new entry", 14, DEEP, True, PANEL).pack(anchor="w")
        self.j_title = tk.Entry(editor, font=("Segoe UI", 11), bg="#FBF7FD", fg=TEXT, relief="flat")
        self.j_title.pack(fill="x", ipady=9, pady=10)
        self.j_title.insert(0, "Give this entry a title...")
        self.j_title.bind("<FocusIn>", lambda e: self.j_title.delete(0, "end") if self.j_title.get()=="Give this entry a title..." else None)
        self.j_text = tk.Text(editor, height=12, wrap="word", font=("Segoe UI", 11), bg="#FBF7FD", fg=TEXT, relief="flat", padx=10, pady=10)
        self.j_text.pack(fill="both", expand=True, pady=(0, 10))
        self.button(editor, "Save my entry  ♡", self.save_journal).pack(anchor="e")
        listing = self.card(body)
        listing.pack(side="right", fill="both", expand=True, padx=(10, 0))
        self.label(listing, "Past entries", 14, DEEP, True, PANEL).pack(anchor="w")
        self.j_list = tk.Listbox(listing, font=("Segoe UI", 10), bg="#FBF7FD", fg=TEXT, relief="flat",
                                 selectbackground=LAVENDER, activestyle="none")
        self.j_list.pack(fill="both", expand=True, pady=10)
        self.refresh_journal_list()
        self.button(listing, "View selected", self.view_journal, color=PURPLE).pack(fill="x", pady=3)
        self.button(listing, "Delete selected", self.delete_journal, color=ROSE).pack(fill="x", pady=3)

    def refresh_journal_list(self):
        self.j_list.delete(0, "end")
        for item in reversed(self.user["journal"]):
            self.j_list.insert("end", f"{item['date']}  ·  {item['title']}")

    def save_journal(self):
        title = self.j_title.get().strip()
        content = self.j_text.get("1.0", "end-1c").strip()
        if not title or title == "Give this entry a title..." or not content:
            messagebox.showwarning("A tiny reminder", "Add a title and write a little something first.")
            return
        self.user["journal"].append({
            "title": title, "content": content,
            "date": datetime.now().strftime("%d %b %Y, %I:%M %p")
        })
        self.user["points"] = self.user.get("points", 0) + 5
        if self.save():
            self.j_title.delete(0, "end")
            self.j_text.delete("1.0", "end")
            self.refresh_journal_list()
            messagebox.showinfo("Saved with love", "Your thoughts have been saved. +5 wellness points ♡")

    def selected_journal_index(self):
        sel = self.j_list.curselection()
        return len(self.user["journal"]) - 1 - sel[0] if sel else None

    def view_journal(self):
        idx = self.selected_journal_index()
        if idx is None:
            messagebox.showinfo("Choose an entry", "Select a journal entry first.")
            return
        item = self.user["journal"][idx]
        win = tk.Toplevel(self.root)
        win.title(item["title"])
        win.geometry("520x420")
        win.configure(bg=BG)
        self.label(win, item["title"], 17, DEEP, True, BG).pack(anchor="w", padx=20, pady=(20, 5))
        self.label(win, item["date"], 9, MUTED, bg=BG).pack(anchor="w", padx=20)
        t = tk.Text(win, wrap="word", font=("Segoe UI", 11), bg=PANEL, fg=TEXT, relief="flat", padx=12, pady=12)
        t.pack(fill="both", expand=True, padx=20, pady=15)
        t.insert("1.0", item["content"])
        t.config(state="disabled")

    def delete_journal(self):
        idx = self.selected_journal_index()
        if idx is None:
            messagebox.showinfo("Choose an entry", "Select a journal entry first.")
            return
        if messagebox.askyesno("Delete entry?", "This journal entry will be removed from this device."):
            self.user["journal"].pop(idx)
            if self.save():
                self.refresh_journal_list()

    # ---------- MOOD ----------
    def page_mood(self):
        self.page_header("Mood garden  ♡", "Every feeling is welcome here. Choose what feels closest today.")
        card = self.card(self.content, 24, 20)
        card.pack(fill="x", padx=30, pady=(0, 15))
        self.label(card, "How is your heart feeling?", 15, DEEP, True, PANEL).pack(anchor="w")
        self.mood_var = tk.StringVar(value="Calm 🌿")
        choices = [
            ("Amazing ✨", "#FCE8B8"), ("Happy ☀", "#FFF0C9"),
            ("Calm 🌿", MINT), ("Okay 🌷", PINK),
            ("Sad 💧", "#E5E8FA"), ("Anxious ☁", LAVENDER),
            ("Tired 🌙", "#E9E3EF")
        ]
        opts = tk.Frame(card, bg=PANEL)
        opts.pack(fill="x", pady=16)
        for text, color in choices:
            rb = tk.Radiobutton(opts, text=text, variable=self.mood_var, value=text,
                                bg=color, fg=TEXT, selectcolor=color, activebackground=color,
                                font=("Segoe UI", 10, "bold"), indicatoron=False,
                                padx=12, pady=12, relief="flat", cursor="hand2")
            rb.pack(side="left", padx=4, expand=True, fill="x")
        self.label(card, "Would you like to add a note?", 11, TEXT, True, PANEL).pack(anchor="w")
        self.mood_note = tk.Text(card, height=3, font=("Segoe UI", 10), bg="#FBF7FD", fg=TEXT, relief="flat", padx=8, pady=8)
        self.mood_note.pack(fill="x", pady=8)
        self.button(card, "Save my check-in  ✦", self.save_mood, color=ROSE).pack(anchor="e")

        tips = self.card(self.content)
        tips.pack(fill="x", padx=30, pady=(0, 15))
        self.label(tips, "A gentle idea for this feeling", 13, DEEP, True, PANEL).pack(anchor="w")
        self.mood_tip_label = self.label(tips, self.mood_tip(self.mood_var.get()), 10, TEXT, bg=PANEL, wraplength=850)
        self.mood_tip_label.pack(anchor="w", pady=(8, 2))
        self.mood_var.trace_add("write", lambda *_: self.mood_tip_label.config(text=self.mood_tip(self.mood_var.get())))

        history = self.card(self.content)
        history.pack(fill="both", expand=True, padx=30, pady=(0, 20))
        self.label(history, "Recent check-ins", 13, DEEP, True, PANEL).pack(anchor="w")
        self.mood_history = tk.Listbox(history, height=6, bg="#FBF7FD", fg=TEXT, relief="flat", font=("Segoe UI", 10))
        self.mood_history.pack(fill="both", expand=True, pady=8)
        self.refresh_mood_history()

    def mood_tip(self, mood):
        """Simple predefined wellbeing ideas; this is not an AI feature."""
        if mood.startswith(("Amazing", "Happy")):
            return "Enjoy the good moment. Write down one thing that made you smile, share your happiness, or take a little dance break."
        if mood.startswith("Calm"):
            return "Protect this peaceful moment. Take five slow breaths, stretch gently, or enjoy a quiet drink of water."
        if mood.startswith("Sad"):
            return "Be gentle with yourself. You do not need to force happiness. Try a comforting song or reach out to someone you trust."
        if mood.startswith("Anxious"):
            return "Pause and ground yourself: notice five things you see, four you feel, and three you hear. Then choose one small next step."
        if mood.startswith("Tired"):
            return "Give yourself a small reset. Rest your eyes, drink some water, and choose rest or just one manageable task."
        return "Take a breath and check what you need right now. A glass of water, a short walk, or one honest journal sentence can be a good start."

    def save_mood(self):
        self.user["moods"].append({
            "mood": self.mood_var.get(),
            "note": self.mood_note.get("1.0", "end-1c").strip(),
            "date": datetime.now().strftime("%d %b %Y, %I:%M %p")
        })
        self.user["points"] = self.user.get("points", 0) + 3
        if self.save():
            self.mood_note.delete("1.0", "end")
            self.refresh_mood_history()
            messagebox.showinfo("Mood saved", "Thank you for checking in with yourself. +3 wellness points ♡")

    def refresh_mood_history(self):
        self.mood_history.delete(0, "end")
        for item in reversed(self.user["moods"]):
            self.mood_history.insert("end", f"{item['date']}   ·   {item['mood']}")

    # ---------- GOALS ----------
    def page_goals(self):
        self.page_header("Tiny goals, lovely growth  ☆", "Little steps count. Make goals that feel kind and achievable.")
        card = self.card(self.content)
        card.pack(fill="x", padx=30, pady=(0, 15))
        row = tk.Frame(card, bg=PANEL)
        row.pack(fill="x")
        self.goal_entry = tk.Entry(row, font=("Segoe UI", 11), bg="#FBF7FD", fg=TEXT, relief="flat")
        self.goal_entry.pack(side="left", fill="x", expand=True, ipady=10, padx=(0, 10))
        self.goal_entry.insert(0, "Example: Drink 6 glasses of water")
        self.goal_entry.bind("<FocusIn>", lambda e: self.goal_entry.delete(0, "end") if self.goal_entry.get()=="Example: Drink 6 glasses of water" else None)
        self.button(row, "Add goal +", self.add_goal).pack(side="right")
        listing = self.card(self.content)
        listing.pack(fill="both", expand=True, padx=30, pady=(0, 25))
        self.label(listing, "Your goal garden", 14, DEEP, True, PANEL).pack(anchor="w")
        self.goal_list = tk.Listbox(listing, font=("Segoe UI", 11), bg="#FBF7FD", fg=TEXT, relief="flat",
                                    selectbackground=LAVENDER, activestyle="none")
        self.goal_list.pack(fill="both", expand=True, pady=10)
        actions = tk.Frame(listing, bg=PANEL)
        actions.pack(fill="x")
        self.button(actions, "Mark complete ✓", self.complete_goal, color="#78A88D").pack(side="left", padx=(0, 8))
        self.button(actions, "Delete", self.delete_goal, color=ROSE).pack(side="left")
        self.refresh_goal_list()

    def refresh_goal_list(self):
        self.goal_list.delete(0, "end")
        for g in self.user["goals"]:
            self.goal_list.insert("end", f"{'✓' if g.get('done') else '○'}  {g['title']}")

    def add_goal(self):
        title = self.goal_entry.get().strip()
        if not title or title == "Example: Drink 6 glasses of water":
            messagebox.showinfo("Add a goal", "Write a small goal first.")
            return
        self.user["goals"].append({"title": title, "done": False})
        if self.save():
            self.goal_entry.delete(0, "end")
            self.refresh_goal_list()

    def complete_goal(self):
        sel = self.goal_list.curselection()
        if not sel:
            messagebox.showinfo("Choose a goal", "Select a goal first.")
            return
        goal = self.user["goals"][sel[0]]
        if not goal.get("done"):
            goal["done"] = True
            self.user["points"] = self.user.get("points", 0) + 10
            if self.save():
                messagebox.showinfo("Lovely work!", "Goal completed! +10 wellness points ⭐")
        else:
            goal["done"] = False
            self.save()
        self.refresh_goal_list()

    def delete_goal(self):
        sel = self.goal_list.curselection()
        if not sel:
            messagebox.showinfo("Choose a goal", "Select a goal first.")
            return
        self.user["goals"].pop(sel[0])
        if self.save():
            self.refresh_goal_list()

    # ---------- PROFILE / LOGOUT ----------
    def page_profile(self):
        self.page_header("Your little profile  ♡", "This is your personal WellNest space.")
        card = self.card(self.content, 25, 25)
        card.pack(fill="x", padx=30, pady=10)
        Mascot(card, "bear", 130, PANEL).pack(side="left", padx=10)
        info = tk.Frame(card, bg=PANEL)
        info.pack(side="left", padx=20)
        self.label(info, self.user["name"], 18, DEEP, True, PANEL).pack(anchor="w", pady=5)
        self.label(info, self.email, 11, MUTED, bg=PANEL).pack(anchor="w")
        self.label(info, f"Wellness points: {self.user.get('points', 0)} ⭐", 11, ROSE, True, PANEL).pack(anchor="w", pady=8)
        self.label(info, "Your journal and check-ins are saved locally on this computer.", 10, MUTED, bg=PANEL).pack(anchor="w")

    def logout(self):
        if messagebox.askyesno("See you soon?", "Log out of WellNest?"):
            self.email = None
            self.user = None
            self.show_auth("signin")


if __name__ == "__main__":
    root = tk.Tk()
    app = WellNestApp(root)
    root.mainloop()
